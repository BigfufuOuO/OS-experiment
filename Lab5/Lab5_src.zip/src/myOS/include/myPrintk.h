#ifndef __MYPRINTK_H__
#define __MYPRINTK_H__

int myPrintk(int color,const char *format, ...);

#endif