#ifndef __VSPRINTF_H__
#define __VSPRINTF_H__

int sprintf(char *buf, const char *fmt, ...);

#endif